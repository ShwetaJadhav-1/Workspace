#include<stdio.h>
int a;
int b=10;

int main()
{
	printf("\n Marvellous Infosystems\n ");
	return 0;
}
